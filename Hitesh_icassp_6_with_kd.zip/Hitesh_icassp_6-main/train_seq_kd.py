"""
train_seq_kd.py
Train a HuBERT/WavLM student whose output is the SAME as the NeMo teacher's
(slu_conformer_transformer_large_slurp): same tokenizer, same Transformer decoder,
same semantics string. Student sees NOISY audio (default 5 dB); teacher sees CLEAN.

Loss (token terms are teacher-forced on the gold target):
  ce      : cross-entropy vs gold semantics
  kd_tok  : T^2 * KL(teacher token distribution || student)
  kd_dec  : 1 - cos(student decoder states, teacher decoder states)
  kd_enc  : 1 - cos(student adapter output, teacher Conformer output)
  ctc     : [item 1] auxiliary character CTC on the plain transcript, from the
            adapter output (the features the decoder attends to) -> better filler words
  L = w_ce*ce + w_tok*kd_tok + w_dec*kd_dec + w_enc*kd_enc + w_ctc*ctc

SpecAugment [item 3]: masking inside WavLM/HuBERT, controlled by
  --no_spec_augment | --mask_time_prob/--mask_time_length/--mask_feature_prob/--mask_feature_length
  (unset values keep the pretrained config; the effective values are printed at startup).

Every evaluation that sets a new best writes dev_predictions_best.jsonl, which
analyze_errors.py turns into an error breakdown. --eval_only --ckpt X evaluates an
existing checkpoint (e.g. your earlier best_student.pt) and writes its predictions.

Ablation example (same epochs/seed for every run):
  A  baseline : --ctc_weight 0
  B  +CTC     : --ctc_weight 0.3
  C  +SpecAug : --ctc_weight 0   --mask_time_prob 0.065 --mask_feature_prob 0.012
  D  both     : --ctc_weight 0.3 --mask_time_prob 0.065 --mask_feature_prob 0.012
"""
import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

from metrics import intent_accuracy, slu_f1
from model_seq import HubertSemanticSLU
from seq_dataset import CharVocab, SemanticsSlurpDataset, TargetFormatter, collate_semantics
from teacher_nemo import (DEFAULT_NEMO_PATH, NemoSLUTeacher, download_teacher,
                          entities_to_tagged_text, parse_semantics, semantics_intent)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--slurp_jsonl_dir", required=True)
    p.add_argument("--audio_root", required=True)
    p.add_argument("--output_dir", default="./ckpt_seq_kd")
    p.add_argument("--noise_dir", default=None)
    p.add_argument("--dev_noise_dir", default=None)
    p.add_argument("--noisy_audio_root", default=None)
    p.add_argument("--snr_db", type=float, default=5.0)
    p.add_argument("--max_audio_seconds", type=float, default=15.0)
    p.add_argument("--seed", type=int, default=42)
    # student
    p.add_argument("--hubert_name", default="microsoft/wavlm-base-plus")
    p.add_argument("--layer_fusion", choices=["single", "weighted_sum"], default="weighted_sum")
    p.add_argument("--semantic_layer", type=int, default=8)
    p.add_argument("--fusion_layers", default=None)
    p.add_argument("--freeze_encoder_layers", type=int, default=0)
    p.add_argument("--adapter_layers", type=int, default=2)
    p.add_argument("--random_decoder", action="store_true")
    # [item 1] auxiliary transcript CTC
    p.add_argument("--ctc_weight", type=float, default=0.3, help="0 disables the CTC head")
    # [item 3] SpecAugment inside the SSL encoder (None = keep pretrained config value)
    p.add_argument("--no_spec_augment", action="store_true")
    p.add_argument("--mask_time_prob", type=float, default=None)
    p.add_argument("--mask_time_length", type=int, default=None)
    p.add_argument("--mask_feature_prob", type=float, default=None)
    p.add_argument("--mask_feature_length", type=int, default=None)
    # teacher
    p.add_argument("--teacher_nemo", default=DEFAULT_NEMO_PATH)
    p.add_argument("--teacher_device", default=None)
    p.add_argument("--teacher_input", choices=["clean", "noisy"], default="clean")
    # optimisation
    p.add_argument("--epochs", type=int, default=40)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--lr", type=float, default=3e-5)
    p.add_argument("--bridge_lr", type=float, default=5e-4)
    p.add_argument("--decoder_lr", type=float, default=1e-4)
    p.add_argument("--freeze_decoder_epochs", type=int, default=1)
    p.add_argument("--grad_clip", type=float, default=5.0)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--log_every", type=int, default=50)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    # loss weights
    p.add_argument("--ce_weight", type=float, default=1.0)
    p.add_argument("--kd_token_weight", type=float, default=1.0)
    p.add_argument("--kd_temperature", type=float, default=2.0)
    p.add_argument("--kd_dec_weight", type=float, default=0.5)
    p.add_argument("--kd_enc_weight", type=float, default=1.0)
    # eval
    p.add_argument("--max_decode_len", type=int, default=128)
    p.add_argument("--eval_teacher", action="store_true")
    p.add_argument("--eval_only", action="store_true", help="Evaluate --ckpt and dump predictions")
    p.add_argument("--ckpt", default=None)
    return p.parse_args()


# --------------------------------------------------------------------------- #
def intents_from_jsonl(path):
    pairs = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                r = json.loads(line)
                if r.get("scenario") is not None and r.get("action") is not None:
                    pairs.setdefault(f"{r['scenario']}_{r['action']}", (r["scenario"], r["action"]))
    return sorted(pairs), pairs


def pad_audio(items, key):
    n = max(it[key].shape[0] for it in items)
    wav = torch.zeros(len(items), n)
    lens = torch.zeros(len(items), dtype=torch.long)
    for i, it in enumerate(items):
        L = it[key].shape[0]
        wav[i, :L], lens[i] = it[key], L
    return wav, lens


def masked_mean(x, mask):
    return (x * mask).sum() / mask.sum().clamp(min=1.0)


def enc_kd_loss(s_enc, t_enc, t_lens):
    Tt = t_enc.shape[1]
    s = F.interpolate(s_enc.transpose(1, 2), size=Tt, mode="linear", align_corners=False).transpose(1, 2)
    mask = (torch.arange(Tt, device=s.device)[None, :] < t_lens[:, None]).float()
    return masked_mean(1.0 - F.cosine_similarity(s, t_enc, dim=-1), mask)


def gold_tagged(entities):
    return entities_to_tagged_text({"entities": [{"type": t, "filler": f} for t, f in entities]})


def word_errors(ref, hyp):
    r, h = ref.split(), hyp.split()
    d = list(range(len(h) + 1))
    for i in range(1, len(r) + 1):
        prev, d[0] = d[0], i
        for j in range(1, len(h) + 1):
            cur = min(d[j] + 1, d[j - 1] + 1, prev + (r[i - 1] != h[j - 1]))
            prev, d[j] = d[j], cur
    return d[len(h)], len(r)


def score(texts, gold_intents, gold_entities):
    sems = [parse_semantics(t) for t in texts]
    pi = [semantics_intent(s) or "<invalid>" for s in sems]
    m = {"intent_accuracy": intent_accuracy(pi, gold_intents)}
    m.update(slu_f1([entities_to_tagged_text(s) for s in sems], [gold_tagged(e) for e in gold_entities]))
    m["invalid"] = sum(s is None for s in sems)
    return m


def fmt_m(m):
    s = (f"intent_acc={m['intent_accuracy']:.4f} slu_f1={m['f1']:.4f} "
         f"(P={m['precision']:.4f} R={m['recall']:.4f}) unparseable={m['invalid']}")
    if "wer" in m:
        s += f" ctc_wer={m['wer']:.4f}"
    return s


def build_hubert_overrides(args):
    if args.no_spec_augment:
        return {"apply_spec_augment": False}
    o = {k: getattr(args, k) for k in ("mask_time_prob", "mask_time_length",
                                       "mask_feature_prob", "mask_feature_length")
         if getattr(args, k) is not None}
    if o:
        o["apply_spec_augment"] = True
    return o


# --------------------------------------------------------------------------- #
@torch.no_grad()
def teacher_outputs(teacher, loader, key):
    out = {}
    for b in tqdm(loader, desc=f"teacher decode ({key})"):
        enc, lens = teacher.encode(b[key].to(teacher.device), b["attention_mask"].sum(-1).to(teacher.device))
        for f, t in zip(b["audio_files"], teacher.decode(enc, lens)):
            out[f] = t
    return out


@torch.no_grad()
def evaluate(student, teacher, loader, device, max_len, char_vocab=None,
             teacher_clean=None, teacher_noisy=None, show=3):
    student.eval()
    rows, texts, intents, ents = [], [], [], []
    werr = wtot = 0
    for b in loader:
        ids, ctc_ids = student.greedy(b["noisy"].to(device), b["attention_mask"].to(device),
                                      teacher.bos, teacher.tok.eos_id, max_len=max_len, return_ctc=True)
        for i, f in enumerate(b["audio_files"]):
            text = teacher.ids_to_text(ids[i])
            row = {"audio_file": f, "gold_intent": b["gold_intents"][i],
                   "gold_entities": [list(e) for e in b["gold_entities"][i]],
                   "gold_sentence": b["gold_sentences"][i], "student": text}
            if ctc_ids is not None and char_vocab is not None:
                row["student_ctc"] = char_vocab.decode_ctc(ctc_ids[i])
                e, n = word_errors(row["gold_sentence"], row["student_ctc"])
                werr, wtot = werr + e, wtot + n
            if teacher_clean is not None:
                row["teacher_clean"] = teacher_clean.get(f, "")
            if teacher_noisy is not None:
                row["teacher_noisy"] = teacher_noisy.get(f, "")
            rows.append(row)
            texts.append(text)
        intents += b["gold_intents"]
        ents += b["gold_entities"]
    student.train()

    m = score(texts, intents, ents)
    if wtot:
        m["wer"] = werr / wtot
    if teacher_clean is not None:
        tt = [r["teacher_clean"] for r in rows]
        m["same_as_teacher"] = sum(a.strip() == c.strip() for a, c in zip(texts, tt)) / max(1, len(tt))
        m["same_intent_as_teacher"] = sum(
            semantics_intent(parse_semantics(a)) == semantics_intent(parse_semantics(c))
            for a, c in zip(texts, tt)) / max(1, len(tt))
    for r in rows[:show]:
        print(f"    student: {r['student']}")
        if "teacher_clean" in r:
            print(f"    teacher: {r['teacher_clean']}")
        if "student_ctc" in r:
            print(f"    ctc    : {r['student_ctc']}   (gold: {r['gold_sentence']})")
    return m, rows


def dump_predictions(rows, path, meta):
    with open(path, "w") as f:
        f.write(json.dumps({"_meta": meta}) + "\n")
        for r in rows:
            f.write(json.dumps(r) + "\n")
    print(f"    predictions -> {path}")


# --------------------------------------------------------------------------- #
def main():
    args = parse_args()
    if (args.noise_dir is None) == (args.noisy_audio_root is None):
        raise SystemExit("Give exactly one of --noise_dir or --noisy_audio_root")
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "seq_kd_args.json").write_text(json.dumps(vars(args), indent=2))
    jdir = Path(args.slurp_jsonl_dir)
    tdev = args.teacher_device or args.device

    # ---- for --eval_only, architecture comes from the checkpoint ----
    ckpt = None
    if args.eval_only:
        if not args.ckpt:
            raise SystemExit("--eval_only needs --ckpt")
        ckpt = torch.load(args.ckpt, map_location="cpu", weights_only=False)
        for k, v in ckpt.get("config", {}).items():
            if k in ("hubert_name", "layer_fusion", "semantic_layer", "fusion_layers", "adapter_layers"):
                setattr(args, k, v)

    # ---- data ----
    common = dict(max_audio_seconds=args.max_audio_seconds, snr_db=args.snr_db,
                  noisy_audio_root=args.noisy_audio_root)
    train_ds = SemanticsSlurpDataset(jdir / "train.jsonl", args.audio_root,
                                     noise_dir=args.noise_dir, deterministic=False, **common)
    dev_ds = SemanticsSlurpDataset(jdir / "devel.jsonl", args.audio_root,
                                   noise_dir=(args.dev_noise_dir or args.noise_dir) if args.noise_dir else None,
                                   deterministic=True, **common)
    print(f"[data] train={len(train_ds)} dev={len(dev_ds)} snr={args.snr_db} dB")

    # ---- char vocab for the transcript CTC head ----
    char_vocab = None
    if ckpt is not None and ckpt.get("ctc_chars"):
        char_vocab = CharVocab(ckpt["ctc_chars"])
    elif ckpt is None and args.ctc_weight > 0:
        char_vocab = CharVocab.from_sentences(ex["sentence"] for ex in train_ds.examples)
        (out_dir / "ctc_chars.json").write_text(json.dumps(char_vocab.chars))
    if char_vocab is not None:
        print(f"[ctc] {len(char_vocab)} symbols (incl. blank): {''.join(char_vocab.chars)!r}")

    # ---- teacher + calibration of its exact output format ----
    intent_list, pairs = intents_from_jsonl(jdir / "train.jsonl")
    teacher = NemoSLUTeacher(download_teacher(args.teacher_nemo), intent_list, pairs, tdev)
    cal_items = [dev_ds[i] for i in range(min(8, len(dev_ds)))]
    wav, lens = pad_audio(cal_items, "clean")
    teacher.calibrate(wav, lens)
    fmt = TargetFormatter(teacher)
    for ds in (train_ds, dev_ds):
        ds.attach_targets(fmt, char_vocab)
    print(f"[format] gold target example: {dev_ds.examples[0]['text']}")

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, drop_last=True,
                              num_workers=args.num_workers, collate_fn=collate_semantics)
    dev_loader = DataLoader(dev_ds, batch_size=args.batch_size, shuffle=False,
                            num_workers=args.num_workers, collate_fn=collate_semantics)

    # teacher references on dev, computed once (clean = KD target, noisy = fair baseline)
    t_clean = teacher_outputs(teacher, dev_loader, "clean")
    t_noisy = teacher_outputs(teacher, dev_loader, "noisy")
    if args.eval_teacher:
        for key, ref in (("clean", t_clean), (f"noisy {args.snr_db} dB", t_noisy)):
            m = score([ref[e["audio_file"]] for e in dev_ds.examples],
                      [f"{e['scenario']}_{e['action']}" for e in dev_ds.examples],
                      [e["entities"] for e in dev_ds.examples])
            print(f"[teacher] dev {key}: {fmt_m(m)}")

    # ---- student ----
    student = HubertSemanticSLU(
        teacher.model, hubert_name=args.hubert_name, layer_fusion=args.layer_fusion,
        semantic_layer=args.semantic_layer,
        fusion_layers=[int(x) for x in args.fusion_layers.split(",")] if args.fusion_layers else None,
        freeze_encoder_layers=args.freeze_encoder_layers, adapter_layers=args.adapter_layers,
        init_decoder_from_teacher=not args.random_decoder,
        ctc_vocab_size=len(char_vocab) if char_vocab is not None else 0,
        hubert_overrides=build_hubert_overrides(args) if ckpt is None else None,
    ).to(args.device)
    c = student.hubert.config
    print(f"[specaug] apply={c.apply_spec_augment} time_prob={c.mask_time_prob} time_len={c.mask_time_length} "
          f"feature_prob={c.mask_feature_prob} feature_len={c.mask_feature_length}")

    meta = {k: getattr(args, k) for k in ("hubert_name", "ctc_weight", "no_spec_augment", "mask_time_prob",
                                          "mask_feature_prob", "snr_db", "epochs", "seed")}

    if args.eval_only:
        missing, unexpected = student.load_state_dict(ckpt["state_dict"], strict=False)
        if missing or unexpected:
            print(f"[eval_only] missing={missing[:5]} unexpected={unexpected[:5]}")
        m, rows = evaluate(student, teacher, dev_loader, args.device, args.max_decode_len,
                           char_vocab, t_clean, t_noisy)
        print(f"[eval_only] student dev noisy: {fmt_m(m)}")
        dump_predictions(rows, out_dir / f"dev_predictions_{Path(args.ckpt).stem}.jsonl",
                         {**meta, "ckpt": args.ckpt})
        return

    groups = [
        {"params": [p for p in student.hubert.parameters() if p.requires_grad], "lr": args.lr},
        {"params": student.bridge_parameters(), "lr": args.bridge_lr},
        {"params": student.decoder_parameters(), "lr": args.decoder_lr},
    ]
    optimizer = torch.optim.AdamW(groups)
    total = max(1, args.epochs * len(train_loader))
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=[args.lr, args.bridge_lr, args.decoder_lr], total_steps=total)
    for name, g in zip(["ssl encoder", "bridge(+ctc)", "decoder"], groups):
        print(f"[optim] {name}: {sum(p.numel() for p in g['params']):,} params, lr={g['lr']}")

    T = args.kd_temperature
    use_ctc = student.ctc_head is not None and args.ctc_weight > 0
    best, step, history = -1.0, 0, []
    for epoch in range(args.epochs):
        freeze_dec = epoch < args.freeze_decoder_epochs and not args.random_decoder
        student.set_decoder_trainable(not freeze_dec)
        student.train()
        running = {}
        pbar = tqdm(train_loader, desc=f"epoch {epoch}{' (decoder frozen)' if freeze_dec else ''}")
        for b in pbar:
            att = b["attention_mask"]
            t_wav = b["clean"] if args.teacher_input == "clean" else b["noisy"]
            with torch.no_grad():
                t_enc, t_lens = teacher.encode(t_wav.to(tdev), att.sum(-1).to(tdev))
                t_logp, t_h = teacher.forced(t_enc, t_lens, b["dec_inp"].to(tdev), b["dec_mask"].to(tdev))
            t_enc, t_lens, t_logp, t_h = (x.to(args.device) for x in (t_enc, t_lens, t_logp, t_h))

            dec_inp, labels, mask = (b[k].to(args.device) for k in ("dec_inp", "labels", "dec_mask"))
            out = student(b["noisy"].to(args.device), att.to(args.device), dec_inp, mask)
            s_logp = out["log_probs"]

            ce = masked_mean(-s_logp.gather(-1, labels.unsqueeze(-1)).squeeze(-1), mask)
            t_logT = F.log_softmax(t_logp / T, -1)
            s_logT = F.log_softmax(s_logp / T, -1)
            kd_tok = masked_mean((t_logT.exp() * (t_logT - s_logT)).sum(-1), mask) * T * T
            kd_dec = masked_mean(1.0 - F.cosine_similarity(out["dec_states"], t_h.float(), dim=-1), mask)
            kd_enc = enc_kd_loss(out["enc"], t_enc.float(), t_lens)
            loss = (args.ce_weight * ce + args.kd_token_weight * kd_tok
                    + args.kd_dec_weight * kd_dec + args.kd_enc_weight * kd_enc)
            terms = {"ce": ce, "kd_tok": kd_tok, "kd_dec": kd_dec, "kd_enc": kd_enc}

            if use_ctc:
                ctc = F.ctc_loss(out["ctc_log_probs"], b["ctc_targets"].to(args.device),
                                 out["enc_lens"], b["ctc_lens"].to(args.device),
                                 blank=char_vocab.blank_id, zero_infinity=True)
                loss = loss + args.ctc_weight * ctc
                terms["ctc"] = ctc

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_([p for p in student.parameters() if p.requires_grad], args.grad_clip)
            optimizer.step()
            scheduler.step()

            step += 1
            for k, v in {"loss": loss, **terms}.items():
                running[k] = 0.98 * running.get(k, float(v)) + 0.02 * float(v)
            if step % args.log_every == 0:
                pbar.set_postfix({k: f"{v:.3f}" for k, v in running.items()})

        m, rows = evaluate(student, teacher, dev_loader, args.device, args.max_decode_len,
                           char_vocab, t_clean, t_noisy)
        print(f"[epoch {epoch}] student dev noisy: {fmt_m(m)}")
        print(f"[epoch {epoch}] identical to teacher(clean): {m['same_as_teacher']:.4f}  "
              f"same intent: {m['same_intent_as_teacher']:.4f}")
        history.append({"epoch": epoch, **{k: v for k, v in m.items() if isinstance(v, (int, float))},
                        **{f"train_{k}": v for k, v in running.items()}})
        (out_dir / "history.json").write_text(json.dumps(history, indent=2))

        ck = {"state_dict": student.state_dict(), "prefix_parts": teacher.prefix_parts,
              "ctc_chars": char_vocab.chars if char_vocab is not None else None,
              "config": {**{k: getattr(args, k) for k in ("hubert_name", "layer_fusion", "semantic_layer",
                                                           "fusion_layers", "adapter_layers")},
                         "ctc_vocab_size": len(char_vocab) if char_vocab is not None else 0}}
        torch.save(ck, out_dir / "last_student.pt")
        if m["f1"] > best:
            best = m["f1"]
            torch.save(ck, out_dir / "best_student.pt")
            dump_predictions(rows, out_dir / "dev_predictions_best.jsonl", {**meta, "epoch": epoch})
            print(f"[epoch {epoch}] new best (noisy dev slu_f1={best:.4f}) -> best_student.pt")


if __name__ == "__main__":
    main()
