"""
model_seq.py
HuBERT/WavLM student with the SAME output head as the NeMo teacher
(slu_conformer_transformer_large_slurp), so both models produce the same thing:

    {'scenario': 'alarm'| 'action': 'set'| 'entities': [{'type': 'time'| 'filler': 'five am'}]}

Architecture
------------
  waveform -> HuBERT (layer-weighted sum, reused from model.py)
           -> adapter: Linear(768 -> 512) + LayerNorm (+ optional Transformer layers)
           -> [teacher-identical] TransformerEmbedding + 3-layer TransformerDecoder
              + classifier over the teacher's SentencePiece vocabulary

The embedding / decoder / classifier are deep copies of the teacher's modules,
so the architecture, vocabulary and tokenizer are exactly the teacher's. By
default they also START from the teacher's trained weights (the student then
mainly has to learn an encoder whose output looks like the teacher's Conformer
output); pass init_decoder_from_teacher=False for a random init.
"""
import copy

import torch
import torch.nn as nn
from transformers import AutoModel

from model import LayerWeightedSum


def _unwrap(x):
    return x[0] if isinstance(x, (tuple, list)) else x


def _reset_parameters(module):
    for m in module.modules():
        if m is not module and hasattr(m, "reset_parameters"):
            m.reset_parameters()


def length_mask(lens, T):
    return (torch.arange(T, device=lens.device)[None, :] < lens[:, None]).float()


class HubertSemanticSLU(nn.Module):
    def __init__(self, teacher_nemo_model, hubert_name="facebook/hubert-base-ls960",
                 layer_fusion="weighted_sum", semantic_layer=8, fusion_layers=None,
                 freeze_feature_extractor=True, freeze_encoder_layers=0,
                 adapter_layers=2, dropout=0.1, init_decoder_from_teacher=True,
                 ctc_vocab_size=0, hubert_overrides=None):
        """
        ctc_vocab_size   : >0 adds an auxiliary character-CTC head on the adapter output
                           (trained on the plain transcript; improves filler words).
        hubert_overrides : config overrides for the SSL model, e.g. SpecAugment
                           {"apply_spec_augment": True, "mask_time_prob": 0.065,
                            "mask_feature_prob": 0.012}. Masking is only applied in train().
        """
        super().__init__()
        self.hubert = AutoModel.from_pretrained(hubert_name, **(hubert_overrides or {}))
        H = self.hubert.config.hidden_size
        n_layers = self.hubert.config.num_hidden_layers
        if freeze_feature_extractor:
            self.hubert.feature_extractor._freeze_parameters()
        for i, layer in enumerate(self.hubert.encoder.layers):
            if i < freeze_encoder_layers:
                for p in layer.parameters():
                    p.requires_grad = False

        self.layer_fusion = layer_fusion
        self.semantic_layer = semantic_layer
        self.fusion_layers = fusion_layers or list(range(1, n_layers + 1))
        if layer_fusion == "weighted_sum":
            self.fusion = LayerWeightedSum(len(self.fusion_layers))

        # --- bridge HuBERT space -> teacher decoder space ---
        d_model = int(teacher_nemo_model.cfg.encoder.d_model)
        self.d_model = d_model
        self.adapter = nn.Sequential(nn.Linear(H, d_model), nn.LayerNorm(d_model), nn.Dropout(dropout))
        self.adapter_encoder = None
        if adapter_layers > 0:
            layer = nn.TransformerEncoderLayer(d_model, nhead=8, dim_feedforward=4 * d_model,
                                               dropout=dropout, batch_first=True, norm_first=True)
            self.adapter_encoder = nn.TransformerEncoder(layer, num_layers=adapter_layers)

        # --- auxiliary transcript CTC head (same features the decoder attends to) ---
        self.ctc_head = None
        if ctc_vocab_size > 0:
            self.ctc_head = nn.Sequential(nn.Dropout(dropout), nn.Linear(d_model, ctc_vocab_size))

        # --- teacher-identical output head ---
        self.embedding = copy.deepcopy(teacher_nemo_model.embedding)
        self.decoder = copy.deepcopy(teacher_nemo_model.decoder)
        self.classifier = copy.deepcopy(teacher_nemo_model.classifier)
        for mod in (self.embedding, self.decoder, self.classifier):
            mod.train()
            for p in mod.parameters():
                p.requires_grad = True
            if not init_decoder_from_teacher:
                _reset_parameters(mod)

    # ------------------------------------------------------------------ #
    def decoder_parameters(self):
        return [p for m in (self.embedding, self.decoder, self.classifier) for p in m.parameters()]

    def bridge_parameters(self):
        mods = [self.adapter] + ([self.adapter_encoder] if self.adapter_encoder is not None else [])
        if self.ctc_head is not None:
            mods.append(self.ctc_head)
        if self.layer_fusion == "weighted_sum":
            mods.append(self.fusion)
        return [p for m in mods for p in m.parameters()]

    def set_decoder_trainable(self, flag):
        for p in self.decoder_parameters():
            p.requires_grad = flag

    # ------------------------------------------------------------------ #
    def encode(self, input_values, attention_mask):
        """-> enc (B, T, d_model) at 20 ms frames, enc_lens (B,)"""
        out = self.hubert(input_values=input_values, attention_mask=attention_mask,
                          output_hidden_states=True)
        if self.layer_fusion == "weighted_sum":
            x = self.fusion([out.hidden_states[i] for i in self.fusion_layers])
        else:
            x = out.hidden_states[self.semantic_layer]
        lens = self.hubert._get_feat_extract_output_lengths(attention_mask.sum(-1)).clamp(max=x.shape[1])
        x = self.adapter(x)
        if self.adapter_encoder is not None:
            pad = length_mask(lens, x.shape[1]) == 0
            x = self.adapter_encoder(x, src_key_padding_mask=pad)
        return x, lens

    def decode_step(self, enc, enc_lens, dec_inp, dec_mask):
        """Teacher-forced decoder: log-probs (B, L, V) and decoder states (B, L, D)."""
        h = self.embedding(dec_inp)
        h = _unwrap(self.decoder(h, dec_mask, enc, length_mask(enc_lens, enc.shape[1])))
        logits = self.classifier(hidden_states=h).float()
        return torch.log_softmax(logits, dim=-1), h

    def forward(self, input_values, attention_mask, dec_inp, dec_mask):
        enc, enc_lens = self.encode(input_values, attention_mask)
        logp, h = self.decode_step(enc, enc_lens, dec_inp, dec_mask)
        out = {"log_probs": logp, "dec_states": h, "enc": enc, "enc_lens": enc_lens}
        if self.ctc_head is not None:
            out["ctc_log_probs"] = torch.log_softmax(self.ctc_head(enc).float(), -1).transpose(0, 1)  # T,B,V
        return out

    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def greedy(self, input_values, attention_mask, bos_id, eos_id, max_len=128, return_ctc=False):
        """Greedy decoding -> list of token-id lists (BOS/EOS stripped).
        With return_ctc=True also returns per-utterance CTC frame argmax ids (or None)."""
        enc, enc_lens = self.encode(input_values, attention_mask)
        ctc_ids = None
        if return_ctc and self.ctc_head is not None:
            am = self.ctc_head(enc).argmax(-1).tolist()
            ctc_ids = [row[:L] for row, L in zip(am, enc_lens.tolist())]
        enc_mask = length_mask(enc_lens, enc.shape[1])
        B = enc.shape[0]
        ys = torch.full((B, 1), bos_id, dtype=torch.long, device=enc.device)
        done = torch.zeros(B, dtype=torch.bool, device=enc.device)
        for _ in range(max_len):
            h = self.embedding(ys)
            h = _unwrap(self.decoder(h, torch.ones_like(ys, dtype=torch.float), enc, enc_mask))
            nxt = self.classifier(hidden_states=h[:, -1:]).float().argmax(-1).squeeze(1)
            nxt = torch.where(done, torch.full_like(nxt, eos_id), nxt)
            ys = torch.cat([ys, nxt[:, None]], dim=1)
            done |= nxt == eos_id
            if bool(done.all()):
                break
        out = []
        for row in ys[:, 1:].tolist():
            out.append(row[: row.index(eos_id)] if eos_id in row else row)
        return (out, ctc_ids) if return_ctc else out
