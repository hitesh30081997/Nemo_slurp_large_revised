"""
analyze_errors.py
Slot-error breakdown + ablation comparison for dev_predictions_*.jsonl files
written by train_seq_kd.py. Pure Python (no torch / NeMo needed).

    python analyze_errors.py A=ckpt_A/dev_predictions_best.jsonl B=ckpt_B/dev_predictions_best.jsonl ...
    python analyze_errors.py --details run=ckpt_D/dev_predictions_best.jsonl --show 10

For every system (each run's student, plus the teacher on noisy and clean audio
from the first file) every gold slot is classified as:

  correct       exact (type, filler) match
  filler~close  right type, filler differs slightly (char error rate <= --close_cer)
                -> typical ASR near-misses ("five a m" vs "five am"); helped by better recognition
  filler~far    right type, clearly different filler
  wrong_type    right filler words, wrong slot type
  missed        gold slot with no matching prediction
and every unmatched predicted slot is "spurious".

Reported metrics:
  slu_f1        exact type+filler F1 (same as training logs)
  f1~word/~char partial-credit F1: type-matched slots earn 1 - normalised word/char
                edit distance. An approximation of SLURP's official SLU-F1; use the
                official toolkit for paper numbers.
  ctc_wer       WER of the auxiliary CTC transcript (if the run has a CTC head)
"""
import argparse
import json
from collections import Counter, defaultdict

from semantics_utils import parse_semantics, semantics_entities, semantics_intent


# --------------------------------------------------------------------------- #
def edit_distance(a, b):
    d = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        prev, d[0] = d[0], i
        for j in range(1, len(b) + 1):
            cur = min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] != b[j - 1]))
            prev, d[j] = d[j], cur
    return d[len(b)]


def norm(s):
    return " ".join(str(s).lower().split())


def cer(ref, hyp):
    return edit_distance(ref, hyp) / max(1, len(ref))


def match_slots(gold, pred, close_cer):
    """gold/pred: lists of (type, filler). Returns dict of categories -> list of pairs/items."""
    g_left = list(gold)
    p_left = []
    res = defaultdict(list)
    for p in pred:                                    # 1) exact
        if p in g_left:
            g_left.remove(p)
            res["correct"].append((p, p))
        else:
            p_left.append(p)
    for p in list(p_left):                            # 2) same type, different filler
        cands = [g for g in g_left if g[0] == p[0]]
        if cands:
            g = min(cands, key=lambda g: cer(g[1], p[1]))
            g_left.remove(g)
            p_left.remove(p)
            res["filler~close" if cer(g[1], p[1]) <= close_cer else "filler~far"].append((g, p))
    for p in list(p_left):                            # 3) same filler, different type
        cands = [g for g in g_left if g[1] == p[1]]
        if cands:
            g = cands[0]
            g_left.remove(g)
            p_left.remove(p)
            res["wrong_type"].append((g, p))
    res["missed"] = [(g, None) for g in g_left]       # 4) leftovers
    res["spurious"] = [(None, p) for p in p_left]
    return res


CATS = ["correct", "filler~close", "filler~far", "wrong_type", "missed"]


def analyze(rows, field, close_cer):
    n_gold = n_pred = 0
    counts = Counter()
    tp_word = tp_char = 0.0
    intent_ok = invalid = 0
    err_in_wrong_intent = err_total = 0
    per_type = defaultdict(lambda: Counter())
    examples = defaultdict(list)
    werr = wtot = 0

    for r in rows:
        text = r.get(field)
        if text is None:
            continue
        sem = parse_semantics(text)
        invalid += sem is None
        gold = [(norm(t), norm(f)) for t, f in r["gold_entities"]]
        pred = [(norm(t), norm(f)) for t, f in semantics_entities(sem)]
        n_gold += len(gold)
        n_pred += len(pred)
        ok_intent = semantics_intent(sem) == r["gold_intent"]
        intent_ok += ok_intent

        res = match_slots(gold, pred, close_cer)
        for c in CATS + ["spurious"]:
            counts[c] += len(res[c])
            for g, p in res[c][:]:
                if len(examples[c]) < 50:
                    examples[c].append((r["audio_file"], g, p, r.get("gold_sentence", "")))
        n_err = sum(len(res[c]) for c in CATS[1:]) + len(res["spurious"])
        err_total += n_err
        if not ok_intent:
            err_in_wrong_intent += n_err

        tp_word += len(res["correct"])
        tp_char += len(res["correct"])
        for c in ("filler~close", "filler~far"):
            for g, p in res[c]:
                gw, pw = g[1].split(), p[1].split()
                tp_word += max(0.0, 1 - edit_distance(gw, pw) / max(1, len(gw)))
                tp_char += max(0.0, 1 - cer(g[1], p[1]))

        for g, p in res["correct"]:
            per_type[g[0]]["tp"] += 1
        for c in CATS[1:]:
            for g, p in res[c]:
                per_type[g[0]]["fn"] += 1
                if p is not None:
                    per_type[p[0]]["fp"] += 1
        for _, p in res["spurious"]:
            per_type[p[0]]["fp"] += 1

        if field == "student" and r.get("student_ctc") is not None:
            ref, hyp = r.get("gold_sentence", "").split(), r["student_ctc"].split()
            werr += edit_distance(ref, hyp)
            wtot += len(ref)

    n = sum(1 for r in rows if r.get(field) is not None)

    def f1(tp):
        p = tp / n_pred if n_pred else 0.0
        rc = tp / n_gold if n_gold else 0.0
        return 2 * p * rc / (p + rc) if p + rc else 0.0

    return {
        "n": n, "intent_acc": intent_ok / max(1, n), "invalid": invalid,
        "slu_f1": f1(counts["correct"]), "f1_word": f1(tp_word), "f1_char": f1(tp_char),
        "n_gold": n_gold, "n_pred": n_pred, "counts": counts,
        "err_share_wrong_intent": err_in_wrong_intent / max(1, err_total),
        "wer": werr / wtot if wtot else None,
        "per_type": per_type, "examples": examples,
    }


# --------------------------------------------------------------------------- #
def load(path):
    meta, rows = {}, []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if "_meta" in obj:
                meta = obj["_meta"]
            else:
                rows.append(obj)
    return meta, rows


def pct(x, tot):
    return f"{100 * x / max(1, tot):5.1f}%"


def print_table(results):
    hdr = (f"{'system':<22}{'intent':>8}{'slu_f1':>8}{'f1~word':>9}{'f1~char':>9}"
           + "".join(f"{c:>14}" for c in CATS) + f"{'spurious':>10}{'ctc_wer':>9}")
    print(hdr)
    print("-" * len(hdr))
    for name, a in results:
        c = a["counts"]
        line = (f"{name:<22}{a['intent_acc']:>8.4f}{a['slu_f1']:>8.4f}{a['f1_word']:>9.4f}{a['f1_char']:>9.4f}"
                + "".join(f"{pct(c[k], a['n_gold']):>14}" for k in CATS)
                + f"{pct(c['spurious'], a['n_pred']):>10}"
                + (f"{a['wer']:>9.4f}" if a["wer"] is not None else f"{'-':>9}"))
        print(line)
    print("\n  category % = share of GOLD slots; spurious % = share of PREDICTED slots")


def print_details(name, a, show, min_support):
    print(f"\n=== {name} ===")
    print(f"utterances={a['n']} gold slots={a['n_gold']} predicted slots={a['n_pred']} "
          f"unparseable outputs={a['invalid']}")
    print(f"slot errors in utterances whose INTENT is also wrong: {100 * a['err_share_wrong_intent']:.1f}%")
    rows = []
    for t, c in a["per_type"].items():
        sup = c["tp"] + c["fn"]
        if sup < min_support:
            continue
        p = c["tp"] / max(1, c["tp"] + c["fp"])
        r = c["tp"] / max(1, sup)
        rows.append((2 * p * r / (p + r) if p + r else 0.0, t, sup, p, r))
    rows.sort()
    print(f"\nworst slot types (support >= {min_support}):")
    print(f"  {'type':<22}{'support':>8}{'P':>8}{'R':>8}{'F1':>8}")
    for f1v, t, sup, p, r in rows[:10]:
        print(f"  {t:<22}{sup:>8}{p:>8.3f}{r:>8.3f}{f1v:>8.3f}")
    for cat in ("filler~close", "filler~far", "wrong_type", "missed", "spurious"):
        ex = a["examples"].get(cat, [])[:show]
        if not ex:
            continue
        print(f"\nexamples: {cat}")
        for fname, g, p, sent in ex:
            gs = f"{g[0]}='{g[1]}'" if g else "-"
            ps = f"{p[0]}='{p[1]}'" if p else "-"
            print(f"  gold {gs:<34} pred {ps:<34} | {sent}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+", help="name=path/to/dev_predictions.jsonl (or just a path)")
    ap.add_argument("--close_cer", type=float, default=0.34)
    ap.add_argument("--details", action="store_true", help="per-type table and error examples")
    ap.add_argument("--show", type=int, default=5)
    ap.add_argument("--min_support", type=int, default=20)
    ap.add_argument("--no_teacher", action="store_true")
    args = ap.parse_args()

    results = []
    first_rows = None
    for spec in args.runs:
        name, path = spec.split("=", 1) if "=" in spec else (spec.rsplit("/", 2)[-2] if "/" in spec else spec, spec)
        meta, rows = load(path)
        if meta:
            print(f"[{name}] {path}  meta={meta}")
        first_rows = first_rows or rows
        results.append((name, analyze(rows, "student", args.close_cer)))
    if not args.no_teacher and first_rows:
        for field, label in (("teacher_noisy", "teacher (noisy)"), ("teacher_clean", "teacher (clean)")):
            if any(field in r for r in first_rows):
                results.append((label, analyze(first_rows, field, args.close_cer)))

    print()
    print_table(results)
    if args.details:
        for name, a in results:
            print_details(name, a, args.show, args.min_support)


if __name__ == "__main__":
    main()
