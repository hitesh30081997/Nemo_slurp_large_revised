"""
kd_dataset.py
Paired (clean, noisy) SLURP data for teacher-student training.

The student always sees NOISY audio; the teacher sees CLEAN audio by default
(so it provides its most reliable knowledge). Two ways to get noisy audio:

  A) On-the-fly mixing (recommended): --noise_dir points at any folder of noise
     recordings (MUSAN noise, DEMAND, WHAM!, ...). Each utterance is mixed with a
     random noise segment at exactly --snr_db (default 5 dB). Training gets a new
     noise draw every epoch; dev uses a fixed per-utterance seed so dev scores
     are comparable across epochs.

  B) Pre-mixed corpus: --noisy_audio_root mirrors the SLURP audio layout
     (slurp_real/, slurp_synth/) with the same file names, already at 5 dB.

Builds on dataset.SlurpDataset, so labels/vocab are identical to train.py.
"""
import math
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from dataset import SlurpDataset, collate_fn, TARGET_SR

AUDIO_EXTS = {".wav", ".flac", ".ogg"}


def _resample(x, sr):
    if sr == TARGET_SR:
        return x
    import librosa
    return librosa.resample(x, orig_sr=sr, target_sr=TARGET_SR).astype(np.float32)


def load_mono(path, start=0, frames=-1):
    x, sr = sf.read(str(path), start=start, frames=frames, dtype="float32", always_2d=True)
    return _resample(x.mean(axis=1), sr)


def mix_at_snr(clean, noise, snr_db, eps=1e-10):
    """Scale `noise` so 10*log10(P_clean / P_noise) == snr_db, then add."""
    p_clean = float(np.mean(clean ** 2))
    p_noise = float(np.mean(noise ** 2))
    if p_clean < eps or p_noise < eps:
        return clean.copy()
    scale = math.sqrt(p_clean / (p_noise * 10.0 ** (snr_db / 10.0)))
    return (clean + scale * noise).astype(np.float32)


class NoiseBank:
    def __init__(self, noise_dir):
        self.files = sorted(p for p in Path(noise_dir).rglob("*") if p.suffix.lower() in AUDIO_EXTS)
        if not self.files:
            raise FileNotFoundError(f"No .wav/.flac/.ogg noise files found under {noise_dir}")

    def sample(self, n, rng):
        """Random noise segment of exactly n samples at 16 kHz."""
        path = self.files[rng.integers(len(self.files))]
        info = sf.info(str(path))
        need = int(math.ceil(n * info.samplerate / TARGET_SR)) + 1
        if info.frames > need:
            start = int(rng.integers(0, info.frames - need + 1))
            x = load_mono(path, start=start, frames=need)
        else:
            x = load_mono(path)
        if x.size == 0:
            return np.zeros(n, dtype=np.float32)
        if x.size < n:  # loop short noise files
            x = np.tile(x, int(math.ceil(n / x.size)))
        return x[:n]


class KDSlurpDataset(SlurpDataset):
    def __init__(self, jsonl_path, audio_root, ctc_vocab, intent2id,
                 max_audio_seconds=15.0, noise_dir=None, noisy_audio_root=None,
                 snr_db=5.0, deterministic=False, seed=1234):
        super().__init__(jsonl_path, audio_root, ctc_vocab, intent2id, max_audio_seconds)
        if (noise_dir is None) == (noisy_audio_root is None):
            raise ValueError("Give exactly one of noise_dir (on-the-fly) or noisy_audio_root (pre-mixed)")
        self.noise = NoiseBank(noise_dir) if noise_dir else None
        self.noisy_root = Path(noisy_audio_root) if noisy_audio_root else None
        self.snr_db = snr_db
        self.deterministic = deterministic
        self.seed = seed

    def _find_noisy(self, fname):
        for sub in ("slurp_real", "slurp_synth", ""):
            p = self.noisy_root / sub / fname
            if p.exists():
                return p
        raise FileNotFoundError(f"No pre-mixed noisy file for {fname} under {self.noisy_root}")

    def __getitem__(self, idx):
        ex = self.examples[idx]
        clean = load_mono(self._find_audio(ex["audio_file"]))[: self.max_samples]

        if self.noisy_root is not None:
            noisy = load_mono(self._find_noisy(ex["audio_file"]))[: self.max_samples]
            n = min(clean.size, noisy.size)
            clean, noisy = clean[:n], noisy[:n]
        else:
            rng = (np.random.default_rng(self.seed + idx) if self.deterministic
                   else np.random.default_rng())
            noisy = mix_at_snr(clean, self.noise.sample(clean.size, rng), self.snr_db)

        return {
            "input_values": torch.from_numpy(np.ascontiguousarray(noisy)),   # student input
            "clean_values": torch.from_numpy(np.ascontiguousarray(clean)),   # teacher input
            "intent_id": ex["intent_id"],
            "ctc_ids": torch.tensor(ex["ctc_ids"], dtype=torch.long),
            "tagged_text": ex["tagged_text"],
            "audio_file": ex["audio_file"],
        }


def kd_collate_fn(batch, pad_id):
    out = collate_fn(batch, pad_id)  # pads noisy audio, CTC targets, intents
    clean = torch.zeros_like(out["input_values"])
    for i, b in enumerate(batch):
        clean[i, : b["clean_values"].shape[0]] = b["clean_values"]
    out["clean_values"] = clean
    out["audio_files"] = [b["audio_file"] for b in batch]
    return out
