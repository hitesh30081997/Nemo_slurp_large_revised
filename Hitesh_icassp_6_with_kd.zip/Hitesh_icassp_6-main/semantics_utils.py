"""
semantics_utils.py
Torch-free helpers for the teacher's semantics strings:
  {'scenario': 'alarm'| 'action': 'set'| 'entities': [{'type': 'time'| 'filler': 'five am'}]}
Shared by teacher_nemo.py, train_seq_kd.py and analyze_errors.py.
"""
import ast
import re

# --------------------------------------------------------------------------- #
# Teacher output -> student label space
# --------------------------------------------------------------------------- #
PREFIX_RE = re.compile(
    r"^(?P<a>.*?'scenario'\s*:\s*')(?P<sc>[^']*)(?P<b>'\s*[,|]\s*'action'\s*:\s*')"
    r"(?P<ac>[^']*)(?P<c>'\s*[,|])"
)
_SC_RE = re.compile(r"'scenario'\s*:\s*'([^']*)'")
_AC_RE = re.compile(r"'action'\s*:\s*'([^']*)'")
_ENT_RE = re.compile(r"'type'\s*:\s*'([^']*)'\s*[,|]\s*'filler'\s*:\s*'([^']*)'")


def parse_semantics(text):
    """Teacher string -> dict, or None if nothing usable.

    The teacher writes '|' in place of ',' (NeMo's own SLURP evaluator does the
    same replace before parsing). Truncated/malformed outputs fall back to regex
    extraction so a missing closing bracket doesn't throw away a correct intent."""
    if not isinstance(text, str):
        return None
    t = text.strip().replace("|", ",")
    try:
        d = ast.literal_eval(t)
        if isinstance(d, dict) and "scenario" in d and "action" in d:
            return d
    except (ValueError, SyntaxError, MemoryError, RecursionError, TypeError):
        pass
    sc, ac = _SC_RE.search(t), _AC_RE.search(t)
    if not (sc and ac):
        return None
    return {"scenario": sc.group(1), "action": ac.group(1),
            "entities": [{"type": a, "filler": b} for a, b in _ENT_RE.findall(t)]}


def render_semantics(scenario, action, entities, sep=", "):
    """Same text as NeMo's str({'scenario':..,'action':..,'entities':[..]}) target,
    with the structural ', ' replaced by the teacher's separator (e.g. '| ').
    With sep=', ' this is byte-identical to str(dict)."""
    q = repr
    ents = sep.join("{" + f"'type': {q(t)}{sep}'filler': {q(f)}" + "}" for t, f in entities)
    return "{" + f"'scenario': {q(scenario)}{sep}'action': {q(action)}{sep}'entities': [{ents}]" + "}"


def nemo_entities(sentence_annotation):
    """Entities exactly as NeMo's process_slurp_data.py extracts them for the teacher."""
    out = []
    for k in range(sentence_annotation.count("[")):
        span = sentence_annotation.split("[")[k + 1].split("]")[0]
        parts = span.split(":")
        if len(parts) < 2:
            continue
        out.append((parts[0].strip().lower(), parts[1].strip().lower()))
    return out


def semantics_intent(sem):
    if not sem or "scenario" not in sem or "action" not in sem:
        return None
    return f"{sem['scenario']}_{sem['action']}"


def semantics_entities(sem):
    out = []
    for ent in (sem or {}).get("entities", []) or []:
        if isinstance(ent, dict) and ent.get("type") and ent.get("filler"):
            out.append((str(ent["type"]).strip().lower(), str(ent["filler"]).strip().lower()))
    return out


def _norm_word(w):
    return re.sub(r"[^\w']", "", w.lower())


def semantics_to_tagged_text(sem, gold_tagged_text, known_slot_types):
    """
    Build the student's CTC target from the teacher's entities.

    The teacher outputs only (type, filler) pairs, not a transcript, so the
    entities are projected onto the gold transcript: each teacher filler is
    located in the gold words and wrapped as  <fill_TYPE> ... <end_fill>.
    Entities whose filler isn't found verbatim, or whose type the student vocab
    doesn't know, are dropped. Returns None if the teacher output is unusable.
    """
    from vocab import strip_tags, END_FILL_TOKEN

    if sem is None:
        return None
    words = strip_tags(gold_tagged_text).split()
    norm = [_norm_word(w) for w in words]
    used = [False] * len(words)
    spans = []  # (start, end, type)
    for typ, filler in semantics_entities(sem):
        if typ not in known_slot_types:
            continue
        ftoks = [t for t in (_norm_word(x) for x in filler.split()) if t]
        n = len(ftoks)
        if n == 0:
            continue
        for i in range(len(norm) - n + 1):
            if norm[i:i + n] == ftoks and not any(used[i:i + n]):
                spans.append((i, i + n, typ))
                for j in range(i, i + n):
                    used[j] = True
                break

    starts = {s: (e, t) for s, e, t in spans}
    out, i = [], 0
    while i < len(words):
        if i in starts:
            e, t = starts[i]
            out += [f"<fill_{t}>"] + words[i:e] + [END_FILL_TOKEN]
            i = e
        else:
            out.append(words[i])
            i += 1
    return " ".join(out)


def entities_to_tagged_text(sem):
    """Slot-only tagged string for scoring the teacher with metrics.slu_f1."""
    from vocab import END_FILL_TOKEN
    return " ".join(f"<fill_{t}> {f} {END_FILL_TOKEN}" for t, f in semantics_entities(sem))
